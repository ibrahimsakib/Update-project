<nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
             <li><a href="registration.php">Registration</a></li>
              <li><a href="login.php">Login</a></li>
        </ul>
    </nav>