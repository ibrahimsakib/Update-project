<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Online Shopping System</title>
    
</head>

<body>
   

<nav>
        <ul>
            <li><a href="./index.php">Homepage</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li><a href="./profile.php">Profile</a></li>
            <li><a href="./products.php">Product Manager</a></li>
             <li><a href="./orders.php">Orders</a></li>
             <li> <a href="../controllers/logout.php">Logout</a></li>
              
        </ul>
    </nav>
</body>

</html>