<?php
include '../controllers/LoggedCheck.php';
if (!loggedCheck()) {
    header('Location: ./login.php');
    exit();
}

require '../models/Order.php';
$orders = getOrders();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders | Online Shopping System </title>
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    
    
    <header>
        <h1>Order List</h1>
    </header>
   
    <?php
    include('./nav.php');
    ?>
    
    
    <table>
        <thead>
            <tr>
                <th>SL</th>
                <th>Product</th>
                <th>Customer Id </th>
                <th> Price ($)</th>
                <th>Quantity</th>
                <th>Total</th>
               
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($orders) == 0) {
                echo '<tr><td colspan="6">No Order Found!</td></tr>';
            }
            foreach ($orders as $key => $item) {
            ?>
                <tr>
                    <td><?php echo $key + 1; ?></td>
                   
                    <td><?php echo $item['name']; ?></td>
                    <td><?php echo $item['customer_id']; ?></td>
                    <td><?php echo $item['price']; ?></td>
                    <td><?php echo $item['quentity']; ?></td>
                    <td><?php echo $item['price'] * $item['quentity']; ?></td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
    <?php
    require './footer.php';
    ?>
</body>

</html>