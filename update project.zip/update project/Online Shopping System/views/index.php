<?php
include '../controllers/LoggedCheck.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Shopping System</title>
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <h1>Online Shopping System</h1>
    </header>
     <?php
    
    if (loggedCheck()) {
    include('./nav.php');
    
}
    else
     {
        include('./nav2.php');
    }
    ?>

   <section style="background-image: url('./image/111.jpg'); background-size: cover; background-repeat: no-repeat; background-position: center; height: 80vh; ">
    <h2>Welcome to Our Online Shop!</h2>
    <p>Find the best deals on your favorite products.</p>
</section>


    <?php 
    include('./footer.php');
    ?> 
</body>
</html>

