<hr>

<footer>
    &copy; <?php echo date('Y'); ?> Online Shopping System
</footer>