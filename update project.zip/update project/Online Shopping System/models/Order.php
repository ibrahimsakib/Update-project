<?php
function getOrders()
{
    // Create a connection to the database
    $conn = mysqli_connect("localhost", "root", "", "online_shop");

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to join orders and products tables using product_id
    $sql = "
        SELECT *
          
        FROM 
            orders
        INNER JOIN 
            products ON orders.product_id = products.id
    ";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Fetch the orders into an array
    $orders = [];
    while ($row = $result->fetch_assoc()) {
        array_push($orders, $row);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Return the orders
    
    return $orders;
}
?>
